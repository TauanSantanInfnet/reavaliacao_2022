package br.com.at.AT_Produto.App;

import br.com.at.AT_Produto.Domain.Cotacao;
import br.com.at.AT_Produto.Domain.Produto;
import br.com.at.AT_Produto.Model.CotacaoModel;
import br.com.at.AT_Produto.Service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ProdutoController {
    @Autowired
    private ProdutoService produtoService;

    @GetMapping(value="/Produto/{id}")
    public ResponseEntity<Produto> findById(@PathVariable Integer id)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(id == null || id == 0){
            return retorno;
        }

        var vaga = produtoService.findById(id);
        return ResponseEntity.ok().body(vaga);
    }
    @RequestMapping(value="/Produto/{id}",method = RequestMethod.DELETE)
    public ResponseEntity<Produto> deleteById(@PathVariable Integer id)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(id == null || id == 0){
            return retorno;
        }

        produtoService.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @RequestMapping(value="/Produto/",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Produto>> getAll()
    {
        var retorno = produtoService.getAll();
        return new ResponseEntity<List<Produto>>(retorno, HttpStatus.OK);
    }

    @RequestMapping(value="/Produto/",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity incluir(@RequestBody Produto model)
    {
        var produto = new Produto();
        produto.setDescricao(model.getDescricao());
        produto.setNome(model.getNome());
        produtoService.save(produto);
        return ResponseEntity.ok().body(produto);
    }

    @RequestMapping(value="/Produto/",method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity update(@RequestBody Produto model)
    {
        var produto = produtoService.findById(model.getId());
        produto.setNome(model.getNome());
        produto.setDescricao(model.getDescricao());
        produtoService.save(produto);
        return ResponseEntity.ok().body(produto);
    }
}
