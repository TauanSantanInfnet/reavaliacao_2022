package br.com.at.AT_Produto.Service;

import br.com.at.AT_Produto.Domain.Cotacao;
import br.com.at.AT_Produto.Domain.Produto;
import br.com.at.AT_Produto.Repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {
    @Autowired
    private ProdutoRepository produtoRepository;

    public Produto save(Produto produto)
    {
        return produtoRepository.save(produto);
    }

    public Produto findById(Integer id)
    {
        return produtoRepository.findFirstById(id);
    }

    public List<Produto> getAll()
    {
        return produtoRepository.getAll();
    }

    public void deleteById(Integer id)
    {
         produtoRepository.deleteById(id);
    }
}
