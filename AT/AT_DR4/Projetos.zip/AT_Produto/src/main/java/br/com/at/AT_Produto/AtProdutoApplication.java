package br.com.at.AT_Produto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtProdutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtProdutoApplication.class, args);
	}

}
