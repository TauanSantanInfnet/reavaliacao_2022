package br.com.at.AT_Produto.Repository;

import br.com.at.AT_Produto.Domain.Cotacao;
import br.com.at.AT_Produto.Domain.Produto;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CotacaoRepository extends CrudRepository<Cotacao, Integer> {
    @Query("from Cotacao p where p.id = :id")
    public Cotacao findFirstById(Integer id);

    @Query("from Cotacao p")
    public List<Cotacao> getAll();
}
