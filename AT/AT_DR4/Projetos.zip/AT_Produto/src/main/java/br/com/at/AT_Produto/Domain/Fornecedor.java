package br.com.at.AT_Produto.Domain;

import javax.persistence.*;
import java.util.List;

@Entity
public class Fornecedor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer id;

    public String cnpj;
    public String razaoSocial;
    public String email;
    @OneToMany
    public List<Cotacao> cotacao;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Cotacao> getCotacao() {
        return cotacao;
    }

    public void setCotacao(List<Cotacao> cotacao) {
        this.cotacao = cotacao;
    }
}
