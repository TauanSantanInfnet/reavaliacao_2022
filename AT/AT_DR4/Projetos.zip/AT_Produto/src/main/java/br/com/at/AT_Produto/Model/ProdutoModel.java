package br.com.at.AT_Produto.Model;

import br.com.at.AT_Produto.Domain.Cotacao;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.List;

public class ProdutoModel {
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer id;
    public String nome;
    public String descricao;

    public Integer cotacaoId;

    public Integer getCotacaoId() {
        return cotacaoId;
    }

    public void setCotacaoId(Integer cotacaoId) {
        this.cotacaoId = cotacaoId;
    }
}
