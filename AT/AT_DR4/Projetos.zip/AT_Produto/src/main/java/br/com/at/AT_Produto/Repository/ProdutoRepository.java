package br.com.at.AT_Produto.Repository;

import br.com.at.AT_Produto.Domain.Produto;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProdutoRepository extends CrudRepository<Produto, Integer> {
    @Query("from Produto p where p.id = :id")
    public Produto findFirstById(Integer id);

    @Query("from Produto p")
    public List<Produto> getAll();
}
