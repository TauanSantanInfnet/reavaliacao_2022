package br.com.at.AT_Produto.App;

import br.com.at.AT_Produto.Domain.Cotacao;
import br.com.at.AT_Produto.Domain.Fornecedor;
import br.com.at.AT_Produto.Domain.Produto;
import br.com.at.AT_Produto.Model.CotacaoModel;
import br.com.at.AT_Produto.Service.CotacaoService;
import br.com.at.AT_Produto.Service.FornecedorService;
import br.com.at.AT_Produto.Service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class CotacaoController {
    @Autowired
    private CotacaoService cotacaoService;
    @Autowired
    private FornecedorService fornecedorService;
    @Autowired
    private ProdutoService produtoService;

    @GetMapping(value="/Cotacao/{id}")
    public ResponseEntity<Cotacao> findById(@PathVariable Integer id)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(id == null || id == 0){
            return retorno;
        }

        var vaga = cotacaoService.findById(id);
        return ResponseEntity.ok().body(vaga);
    }

    @RequestMapping(value="/Cotacao/{id}",method = RequestMethod.DELETE)
    public ResponseEntity<Cotacao> deleteById(@PathVariable Integer id)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(id == null || id == 0){
            return retorno;
        }

        cotacaoService.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @RequestMapping(value="/Cotacao/",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Cotacao>> getAll()
    {
        var retorno = cotacaoService.getAll();
        return new ResponseEntity<List<Cotacao>>(retorno, HttpStatus.OK);
    }

    @RequestMapping(value="/Cotacao/",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity incluir(@RequestBody CotacaoModel model)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(model.getFornecedor() == null || model.getProdutoId().equals("") ){
            return retorno;
        }

        var produto = produtoService.findById(model.getProdutoId());
        if(produto == null){
            return retorno;
        }
        List<Produto> produtos = new ArrayList<Produto>() ;
        produtos.add(produto);

        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setCnpj(model.Fornecedor.getCnpj());
        fornecedor.setEmail(model.getFornecedor().getEmail());
        fornecedor.setRazaoSocial(model.Fornecedor.getRazaoSocial());
        fornecedorService.add(fornecedor);

        Cotacao cotacao = new Cotacao();
        cotacao.setValor(model.getValor());
        cotacao.setProdutos(produtos);
        cotacao.setFornecedor(fornecedor);
        cotacaoService.save(cotacao);

        return ResponseEntity.ok().body(cotacao);
    }

    @RequestMapping(value="/Cotacao/",method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity update(@RequestBody CotacaoModel model)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(model.getFornecedor() == null || model.getProdutoId().equals("") || model.getValor() == 0 || model.getId().equals("")){
            return retorno;
        }
        var cotacao = cotacaoService.findById(model.getId());
        if(cotacao == null){
            return retorno;
        }

        var produto = produtoService.findById(model.getProdutoId());
        if(produto == null){
            return retorno;
        }
        cotacao.produtos.add(produto);

        cotacao.fornecedor.setCnpj(model.Fornecedor.getCnpj());
        cotacao.fornecedor.setEmail(model.getFornecedor().getEmail());
        cotacao.fornecedor.setRazaoSocial(model.Fornecedor.getRazaoSocial());

        cotacao.setValor(model.getValor());
        cotacaoService.save(cotacao);
        cotacaoService.save(cotacao);

        return ResponseEntity.ok().body(cotacao);
    }

}
