package br.com.at.AT_Produto.Model;

import br.com.at.AT_Produto.Domain.Fornecedor;
import br.com.at.AT_Produto.Domain.Produto;

import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import java.util.List;

public class CotacaoModel {
    public Integer id;
    public float valor;

    public Integer produtoId;
    public Fornecedor Fornecedor;

    public br.com.at.AT_Produto.Domain.Fornecedor getFornecedor() {
        return Fornecedor;
    }

    public void setFornecedor(br.com.at.AT_Produto.Domain.Fornecedor fornecedor) {
        Fornecedor = fornecedor;
    }

    public Integer getProdutoId() {
        return produtoId;
    }

    public void setProdutoId(Integer produtoId) {
        this.produtoId = produtoId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }




}
