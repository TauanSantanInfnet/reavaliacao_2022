package br.com.at.AT_Produto.Service;

import br.com.at.AT_Produto.Domain.Fornecedor;
import br.com.at.AT_Produto.Repository.FornecedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FornecedorService {
    @Autowired
    FornecedorRepository fornecedorRepository;

    public void add(Fornecedor fornecedor)
    {
        fornecedorRepository.save(fornecedor);
    }
}
