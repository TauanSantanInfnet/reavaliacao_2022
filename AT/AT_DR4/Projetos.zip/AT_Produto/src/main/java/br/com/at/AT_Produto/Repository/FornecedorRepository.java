package br.com.at.AT_Produto.Repository;

import br.com.at.AT_Produto.Domain.Fornecedor;
import br.com.at.AT_Produto.Domain.Produto;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FornecedorRepository  extends CrudRepository<Fornecedor, Integer> {
}
