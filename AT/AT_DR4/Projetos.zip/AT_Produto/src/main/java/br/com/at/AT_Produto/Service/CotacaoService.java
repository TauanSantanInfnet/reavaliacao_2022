package br.com.at.AT_Produto.Service;

import br.com.at.AT_Produto.Domain.Cotacao;
import br.com.at.AT_Produto.Repository.CotacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CotacaoService {
    @Autowired
    private CotacaoRepository cotacaoRepository;

    public Cotacao save(Cotacao produto)
    {
        return cotacaoRepository.save(produto);
    }

    public Cotacao findById(Integer id)
    {
        return cotacaoRepository.findFirstById(id);
    }

    public List<Cotacao> getAll()
    {
        return cotacaoRepository.getAll();
    }

    public void deleteById(Integer id)
    {
        cotacaoRepository.deleteById(id);
    }
}
