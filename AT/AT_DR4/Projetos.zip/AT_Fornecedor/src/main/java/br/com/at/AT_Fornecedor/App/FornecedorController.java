package br.com.at.AT_Fornecedor.App;

import br.com.at.AT_Fornecedor.Domain.Fornecedor;
import br.com.at.AT_Fornecedor.Model.FornecedorModel;
import br.com.at.AT_Fornecedor.Service.FornecedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class FornecedorController {
    @Autowired
    private FornecedorService fornecedorService;
    @GetMapping(value="/Fornecedor/{id}")
    public ResponseEntity<Fornecedor> findById(@PathVariable Integer id)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(id == null || id == 0){
            return retorno;
        }

        var vaga = fornecedorService.findById(id);
        return ResponseEntity.ok().body(vaga);
    }
    @RequestMapping(value="/Fornecedor/{id}",method = RequestMethod.DELETE)
    public ResponseEntity<Fornecedor> deleteById(@PathVariable Integer id)
    {
        ResponseEntity retorno = ResponseEntity.badRequest().build();
        if(id == null || id == 0){
            return retorno;
        }

        fornecedorService.deleteById(id);
        return ResponseEntity.ok().build();
    }

    @RequestMapping(value="/Fornecedor/",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Fornecedor>> getAll()
    {
        var retorno = fornecedorService.getAll();
        return new ResponseEntity<List<Fornecedor>>(retorno, HttpStatus.OK);
    }


    @RequestMapping(value="/Fornecedor/",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity incluir(@RequestBody FornecedorModel model)
    {
        var fornecedor = new Fornecedor();
        fornecedor.setCnpj(model.getCnpj());
        fornecedor.setEmail(model.getEmail());
        fornecedor.setRazaoSocial(model.getRazaoSocial());
        fornecedorService.save(fornecedor);
        return ResponseEntity.ok().body(fornecedor);
    }

    @RequestMapping(value="/Fornecedor/",method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
    public ResponseEntity update(@RequestBody FornecedorModel model)
    {
        var fornecedor = fornecedorService.findById(model.getId());
        fornecedor.setCnpj(model.getCnpj());
        fornecedor.setEmail(model.getEmail());
        fornecedor.setRazaoSocial(model.getRazaoSocial());
        fornecedorService.save(fornecedor);
        return ResponseEntity.ok().body(fornecedor);
    }
}
