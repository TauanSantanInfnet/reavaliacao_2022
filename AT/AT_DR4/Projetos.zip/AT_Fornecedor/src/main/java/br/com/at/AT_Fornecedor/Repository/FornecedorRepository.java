package br.com.at.AT_Fornecedor.Repository;

import br.com.at.AT_Fornecedor.Domain.Fornecedor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FornecedorRepository extends CrudRepository<Fornecedor, Integer> {
    @Query("from Fornecedor p where p.id = :id")
    public Fornecedor findFirstById(Integer id);

    @Query("from Fornecedor p")
    public List<Fornecedor> getAll();
}