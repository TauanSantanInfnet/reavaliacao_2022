package br.com.at.AT_Fornecedor.Service;

import br.com.at.AT_Fornecedor.Domain.Fornecedor;
import br.com.at.AT_Fornecedor.Repository.FornecedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FornecedorService {
    @Autowired
    private FornecedorRepository fornecedorRepository;

    public Fornecedor save(Fornecedor produto)
    {
        return fornecedorRepository.save(produto);
    }

    public Fornecedor findById(Integer id)
    {
        return fornecedorRepository.findFirstById(id);
    }

    public List<Fornecedor> getAll()
    {
        return fornecedorRepository.getAll();
    }

    public void deleteById(Integer id)
    {
        fornecedorRepository.deleteById(id);
    }
}
