package br.com.at.AT_Fornecedor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtFornecedorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtFornecedorApplication.class, args);
	}

}
