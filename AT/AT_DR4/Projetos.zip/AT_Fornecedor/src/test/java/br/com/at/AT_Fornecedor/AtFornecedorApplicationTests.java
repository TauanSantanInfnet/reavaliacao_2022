package br.com.at.AT_Fornecedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtFornecedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
