package br.com.at.AT_Web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
