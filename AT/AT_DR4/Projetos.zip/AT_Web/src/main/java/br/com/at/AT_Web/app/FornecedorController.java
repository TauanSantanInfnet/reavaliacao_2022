package br.com.at.AT_Web.app;

import br.com.at.AT_Web.infra.FornecedorService;
import br.com.at.AT_Web.infra.ProdutoService;
import br.com.at.AT_Web.model.Fornecedor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class FornecedorController {
    @Autowired
    FornecedorService fornecedorService;

    @GetMapping(value="/Fornecedor")
    public String index(Model model)
    {
        model.addAttribute("lista", fornecedorService.getAll());
        return "Fornecedor/FornecedorIndex";
    }
    @GetMapping(value="/Fornecedor/Cadastrar")
    public String cadastrar()
    {
        return "Fornecedor/NovoFornecedor";
    }

    @PostMapping(value = "/Fornecedor")
    public String save(Model model, br.com.at.AT_Web.model.Fornecedor fornecedor){
        fornecedorService.cadastrar(fornecedor);
        model.addAttribute("mensagem", "Fornecedor incluído");
        return index(model);
    }

    @GetMapping(value = "/Fornecedor/{id}/excluir")
    public String delete(Model model, @PathVariable Integer id){
        fornecedorService.deleteById(id);
        model.addAttribute("mensagem", "Fornecedor excluído");
        return index(model);
    }
}
