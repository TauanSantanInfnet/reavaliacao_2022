package br.com.at.AT_Web.model;

public class Produto {
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer id;
    public String nome;
    public String descricao;

    public Integer cotacaoId;

    public Integer getCotacaoId() {
        return cotacaoId;
    }

    public void setCotacaoId(Integer cotacaoId) {
        this.cotacaoId = cotacaoId;
    }
}
