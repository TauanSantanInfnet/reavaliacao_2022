package br.com.at.AT_Web.app;

import br.com.at.AT_Web.infra.CotacaoService;
import br.com.at.AT_Web.infra.FornecedorService;
import br.com.at.AT_Web.infra.ProdutoService;
import br.com.at.AT_Web.model.Cotacao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CotacaoController {
    @Autowired
    CotacaoService cotacaoService;
    @Autowired
    FornecedorService fornecedorService;

    @GetMapping(value="/Cotacao")
    public String index(Model model)
    {
        model.addAttribute("lista", cotacaoService.getAll());
        return "Cotacao/CotacaoIndex";
    }

    @GetMapping(value = "/Cotacao/{id}/excluir")
    public String delete(Model model, @PathVariable Integer id){
        cotacaoService.deleteById(id);
        model.addAttribute("mensagem", "Cotação excluída");
        return index(model);
    }

    @PostMapping(value = "/Cotacao")
    public String save(Model model, Cotacao cotacao){
        var fornecedor = fornecedorService.getById(cotacao.getFornecedorId());
        cotacao.setFornecedor(fornecedor);
        cotacaoService.cadastrar(cotacao);
        model.addAttribute("mensagem", "Cotação incluída");
        return index(model);
    }

}
