package br.com.at.AT_Web.infra;


import kong.unirest.GenericType;
import kong.unirest.Unirest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FornecedorService {
    public List<br.com.at.AT_Web.model.Fornecedor> getAll() {
        var retorno = Unirest.get("http://localhost:7082/Fornecedor/")
                .header("Content-Type", "application/json")
                .asObject(new GenericType<List<br.com.at.AT_Web.model.Fornecedor>>() {
                })
                .getBody();


        return retorno;
    }
    public br.com.at.AT_Web.model.Fornecedor getById(Integer id) {
        var retorno = Unirest.get("http://localhost:7082/Fornecedor/" + id)
                .header("Content-Type", "application/json")
                .asObject(br.com.at.AT_Web.model.Fornecedor.class)
                .getBody();

        return retorno;
    }


    public br.com.at.AT_Web.model.Fornecedor cadastrar(br.com.at.AT_Web.model.Fornecedor fornecedor) {

       var retorno = Unirest.post("http://localhost:7082/Fornecedor/")
                .header("Content-Type", "application/json")
                .body(fornecedor)
                .asObject(br.com.at.AT_Web.model.Fornecedor.class);

        if(retorno.getStatus() != 200){
            return null;
        }
        else{
            return retorno.getBody();
        }
    }
    public void deleteById(Integer id) {
        var retorno = Unirest.delete("http://localhost:7082/Fornecedor/" + id)
                .header("Content-Type", "application/json")
                .asEmpty();
    }
}