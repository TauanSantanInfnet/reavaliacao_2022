package br.com.at.AT_Web.app;

import br.com.at.AT_Web.infra.FornecedorService;
import br.com.at.AT_Web.infra.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProdutoController {
    @Autowired
    ProdutoService produtoService;
    @Autowired
    FornecedorService fornecedorService;

    @GetMapping(value="/Produto")
    public String index(Model model)
    {
        model.addAttribute("lista", produtoService.getAll());
        return "Produto/ProdutoIndex";
    }
    @GetMapping(value="/Produto/Cadastrar")
    public String cadastrar()
    {
        return "Produto/NovoProduto";
    }

    @PostMapping(value = "/Produto")
    public String save(Model model, br.com.at.AT_Web.model.Produto produto){
        produtoService.cadastrar(produto);
        model.addAttribute("mensagem", "Produto incluído");
        return index(model);
    }

    @GetMapping(value = "/Produto/{id}/excluir")
    public String delete(Model model, @PathVariable Integer id){
        produtoService.deleteById(id);
        model.addAttribute("mensagem", "Produto excluído");
        return index(model);
    }
    @GetMapping(value = "/Produto/{id}/cotar")
    public String cotar(Model model, @PathVariable Integer id){
        var produto = produtoService.getById(id);
        var fornecedores = fornecedorService.getAll();
        model.addAttribute("lista", fornecedores);
        model.addAttribute("produtoId", id);
        model.addAttribute("produtoNome", produto.getNome());
        return "Cotacao/NovaCotacao";
    }

//    @PostMapping(value="/login/CadastroUsuario")
//    public String CadastroUsuarioPost(Model model, Usuario usuario)
//    {
//        var usuarioDb = usuarioService.cadastrar(usuario);
//        if(usuarioDb == null){
//            model.addAttribute("mensagem", "Erro ao cadastrar o usuário. Verifique os dados informados");
//            return CadastroSolicitanteGet(model);
//        }else{
//            model.addAttribute("usuario",usuarioDb);
//            return "home";
//        }
//
//
//    }
}
