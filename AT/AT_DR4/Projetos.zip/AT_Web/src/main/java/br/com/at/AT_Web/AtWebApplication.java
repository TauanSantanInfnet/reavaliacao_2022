package br.com.at.AT_Web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtWebApplication.class, args);
	}

}
