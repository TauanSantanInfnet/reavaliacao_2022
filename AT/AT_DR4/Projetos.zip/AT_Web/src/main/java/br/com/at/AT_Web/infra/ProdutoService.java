package br.com.at.AT_Web.infra;


import kong.unirest.GenericType;
import kong.unirest.Unirest;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class ProdutoService {
    public List<br.com.at.AT_Web.model.Produto> getAll() {
        var retorno = Unirest.get("http://localhost:8081/Produto/")
                .header("Content-Type", "application/json")
                .asObject(new GenericType<List<br.com.at.AT_Web.model.Produto>>() {
                })
                .getBody();


        return retorno;
    }


    public br.com.at.AT_Web.model.Produto cadastrar(br.com.at.AT_Web.model.Produto produto) {

       var retorno = Unirest.post("http://localhost:8081/Produto/")
                .header("Content-Type", "application/json")
                .body(produto)
                .asObject(br.com.at.AT_Web.model.Produto.class);

        if(retorno.getStatus() != 200){
            return null;
        }
        else{
            return retorno.getBody();
        }
    }
    public void deleteById(Integer id) {
        var retorno = Unirest.delete("http://localhost:8081/Produto/" + id)
                .header("Content-Type", "application/json")
                .asEmpty();
    }

    public br.com.at.AT_Web.model.Produto getById(Integer id) {
        var retorno = Unirest.get("http://localhost:8081/Produto/" + id)
                .header("Content-Type", "application/json")
                .asObject(new GenericType<br.com.at.AT_Web.model.Produto>() {
                })
                .getBody();


        return retorno;
    }
}