package br.com.at.AT_Web.infra;

import br.com.at.AT_Web.model.Cotacao;
import br.com.at.AT_Web.model.Produto;
import kong.unirest.GenericType;
import kong.unirest.Unirest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CotacaoService {
    public List<Cotacao> getAll() {
        var retorno = Unirest.get("http://localhost:8081/Cotacao/")
                .header("Content-Type", "application/json")
                .asObject(new GenericType<List<Cotacao>>() {
                })
                .getBody();


        return retorno;
    }


    public br.com.at.AT_Web.model.Cotacao cadastrar(br.com.at.AT_Web.model.Cotacao cotacao) {

        var retorno = Unirest.post("http://localhost:8081/Cotacao/")
                .header("Content-Type", "application/json")
                .body(cotacao)
                .asObject(br.com.at.AT_Web.model.Cotacao.class);

        if(retorno.getStatus() != 200){
            return null;
        }
        else{
            return retorno.getBody();
        }
    }

    public void deleteById(Integer id) {
        var retorno = Unirest.delete("http://localhost:8081/Cotacao/" + id)
                .header("Content-Type", "application/json")
                .asEmpty();
    }
}
